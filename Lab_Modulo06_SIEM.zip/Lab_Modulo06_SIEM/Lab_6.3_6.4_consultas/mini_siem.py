#!/usr/bin/env python3
"""mini_siem.py: um "SIEM de bolso" para treinar consultas sem instalar nada.

Uso:
  python3 mini_siem.py eventos.ndjson 'FILTROS | COMANDO | COMANDO ...'
  python3 mini_siem.py csv/*.csv 'FILTROS | COMANDO ...'      (aceita vários arquivos .ndjson ou .csv)

Filtros (separados por espaço, todos precisam bater, como um AND):
  campo=valor        igualdade (aceita * como curinga: url=*boleto*)
  campo!=valor       diferente
  campo>=valor       maior ou igual (números ou horários ISO, ex.: timestamp>=2026-11-12T14:00)
  campo<=valor       menor ou igual
  palavra            busca livre: a palavra aparece em qualquer campo (sem diferenciar maiúsculas)
  OR não existe aqui de propósito: faça duas consultas. SIEM de verdade tem.

Comandos depois do |:
  table c1,c2,...        mostra só essas colunas
  stats count by c1,c2   conta eventos por grupo
  stats dc(cX) by c1     conta valores DISTINTOS de cX por grupo
  sort campo / sort -campo   ordena (o - inverte)
  head N                 primeiras N linhas
  count                  só o total

Exemplos:
  python3 mini_siem.py eventos.ndjson 'src_ip=203.0.113.77 | stats count by dataset,outcome'
  python3 mini_siem.py eventos.ndjson 'dataset=windows event_id=4624 logon_type=10 | table timestamp,host,user,src_ip'
"""
import json, sys, fnmatch, re, csv


def load(path):
    with open(path, encoding='utf-8', newline='') as f:
        if path.lower().endswith('.csv'):
            return [{k: v for k, v in r.items() if v not in (None, '')} for r in csv.DictReader(f)]
        return [json.loads(l) for l in f if l.strip()]


def val(ev, k):
    v = ev.get(k)
    return '' if v is None else str(v)


def cmp(a, b):
    try:
        return (float(a) > float(b)) - (float(a) < float(b))
    except ValueError:
        return (a > b) - (a < b)


def match(ev, term):
    m = re.match(r'^([\w.]+)(!=|>=|<=|=)(.*)$', term)
    if not m:
        t = term.lower()
        return any(t in str(v).lower() for v in ev.values())
    k, op, v = m.groups()
    x = val(ev, k)
    if op == '=':
        return fnmatch.fnmatchcase(x.lower(), v.lower())
    if op == '!=':
        return not fnmatch.fnmatchcase(x.lower(), v.lower())
    if x == '':
        return False
    return cmp(x, v) >= 0 if op == '>=' else cmp(x, v) <= 0


def show(rows, cols):
    if not rows:
        print('(nenhum resultado)')
        return
    w = [max(len(c), *(len(str(r.get(c, ''))) for r in rows)) for c in cols]
    print('  '.join(c.ljust(w[i]) for i, c in enumerate(cols)))
    print('  '.join('-' * w[i] for i in range(len(cols))))
    for r in rows:
        print('  '.join(str(r.get(c, '')).ljust(w[i]) for i, c in enumerate(cols)))
    print(f'\n{len(rows)} linha(s)')


def main():
    if len(sys.argv) < 3:
        print(__doc__)
        sys.exit(1)
    evs = []
    for path in sys.argv[1:-1]:
        evs += load(path)
    evs.sort(key=lambda e: str(e.get('timestamp', '')))
    parts = [p.strip() for p in sys.argv[-1].split('|')]
    terms = parts[0].split() if parts[0] else []
    rows = [e for e in evs if all(match(e, t) for t in terms)]
    cols = None
    for cmd in parts[1:]:
        tok = cmd.split(None, 1)
        name, arg = tok[0].lower(), (tok[1] if len(tok) > 1 else '')
        if name == 'table':
            cols = [c.strip() for c in arg.split(',')]
        elif name == 'stats':
            m = re.match(r'^(count|dc\(([\w.]+)\))(?:\s+by\s+(.+))?$', arg.strip())
            if not m:
                sys.exit('stats: use "stats count by campo" ou "stats dc(campo) by campo"')
            by = [c.strip() for c in m.group(3).split(',')] if m.group(3) else []
            groups = {}
            for r in rows:
                key = tuple(val(r, c) for c in by)
                groups.setdefault(key, []).append(r)
            out = []
            for key, rs in groups.items():
                d = dict(zip(by, key))
                if m.group(2):
                    d['dc(' + m.group(2) + ')'] = len({val(r, m.group(2)) for r in rs})
                else:
                    d['count'] = len(rs)
                out.append(d)
            agg = 'count' if not m.group(2) else 'dc(' + m.group(2) + ')'
            rows = sorted(out, key=lambda d: -d[agg])
            cols = by + [agg]
        elif name == 'sort':
            k = arg.strip()
            rev = k.startswith('-')
            k = k.lstrip('-')
            rows = sorted(rows, key=lambda r: (lambda v: (0, float(v)) if re.match(r'^-?\d+(\.\d+)?$', v) else (1, v))(val(r, k)), reverse=rev)
        elif name == 'head':
            rows = rows[:int(arg or 10)]
        elif name == 'count':
            print(len(rows))
            return
        else:
            sys.exit('comando desconhecido: ' + name)
    if cols is None:
        cols = ['timestamp', 'dataset', 'host', 'user', 'src_ip', 'dst_ip', 'dst_port', 'action', 'outcome', 'event_id', 'message']
        cols = [c for c in cols if any(c in r for r in rows)]
    show(rows, cols)


if __name__ == '__main__':
    main()
